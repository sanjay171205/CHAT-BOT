# main.py - Entry point for the chatbot project

from chatbot import chatbot_response
import streamlit as st

st.title("AI Customer Support Chatbot")
user_input = st.text_input("Enter your query:")
if st.button("Get Response"):
    response = chatbot_response(user_input)
    st.write(response)

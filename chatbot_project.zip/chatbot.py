import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from transformers import pipeline
import nltk

nltk.download('punkt')
nltk.download('stopwords')

# Load dataset
data = pd.read_csv("data/customer_support_twitter.csv")
data.dropna(subset=['text', 'category'], inplace=True)
data.drop_duplicates(inplace=True)

# Text Vectorization
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(data['text'])
y = data['category']

# Model Training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Sentiment Analysis Pipeline
sentiment_analyzer = pipeline("sentiment-analysis")

# Chatbot logic
def chatbot_response(user_input):
    vec = vectorizer.transform([user_input])
    intent = model.predict(vec)[0]
    sentiment = sentiment_analyzer(user_input)[0]
    return f"Intent: {intent}\nSentiment: {sentiment['label']} ({sentiment['score']:.2f})"
